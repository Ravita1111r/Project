from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # This will serve the main page for the chat app
    path('chat/<str:room_name>/', views.chat_room, name='chat_room'),  # URL for entering specific chat rooms
]
