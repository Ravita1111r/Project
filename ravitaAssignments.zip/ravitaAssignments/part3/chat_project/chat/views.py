from django.shortcuts import render

# View for the main page (could be a landing page or room listing)
def index(request):
    return render(request, 'chat/index.html')

# View for a specific chat room
def chat_room(request, room_name):
    return render(request, 'chat/chat.html', {
        'room_name': room_name
    })
